module.exports = {
  SIGNIN: '/signin',
  SIGNUP: '/signup',
  CONFIRMSIGNUP: '/confirm-signup',
  FORGOTPWD: '/forgot-password',
  OTPFORFORGOTPWD: '/opt-forgot-password',
}

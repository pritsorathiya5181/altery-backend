const AWS = require('aws-sdk')

AWS.config.update({
  region: 'us-east-1',
  accessKeyId:'AKIAV3YS7YLB25VGNF6R',
  secretAccessKey: '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',
})

const client = new AWS.DynamoDB.DocumentClient()
const tableName = 'complaints'

const saveImage = async (newComplaint) => {
  return new Promise(async function (resolve, reject) {
  const res =  newComplaint.photos.map(async (photo, index) => {
      if (photo.isPhoto) {
        var buf = Buffer.from(
          photo.photoUrl.replace(/^data:image\/\w+;base64,/, ''),
          'base64'
        )

        const params = {
          Bucket: 'alterybucket',
          Key: `${newComplaint.complaintId}${index}.jpeg`,
          Body: buf,
          ContentEncoding: 'base64',
          ContentType: 'image/jpeg',
        }

        let uploadedResponse = JSON.parse(JSON.stringify(photo))
        const s3 = new AWS.S3({
          accessKeyId: 'AKIAV3YS7YLB25VGNF6R',
          secretAccessKey: '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',
        })
        
        const response = await s3.upload(params).promise().then((data) => {
          console.log("data====",data)
          uploadedResponse.photoUrl = data.Location
          return uploadedResponse
        }, (error) => {
          console.error('Do your custom error handling here. I am just gonna log it: ', error);
        })
      
        return response;
      } else {
        return photo
      }
    })
    const s3Photos = await Promise.all(res);
      resolve(s3Photos)
  })
}

exports.addNewComplaints = async  (newComplaintBody) => {
  const processedComplaint = await saveImage(newComplaintBody)
  
  var params = {
    TableName: tableName,
    Item: {
      complaintId: newComplaintBody.complaintId,
      subject: newComplaintBody.subject,
      severity: newComplaintBody.severity,
      category: newComplaintBody.category,
      username: newComplaintBody.username,
      complaintStatus: newComplaintBody.complaintStatus,
      useremail: newComplaintBody.useremail,
      photos: processedComplaint,
      description: newComplaintBody.description,
      location: newComplaintBody.location,
    },
  }
  
  return await client.put(params).promise().then(() => {
    const successResponse = {
        message: 'Successfully added new complaint',
        success: true,
      }
    return successResponse;
  }, (error) => {
    const errorResponse = {
        message: 'Unable to add new complaint',
        success: false,
      }  
    return errorResponse;
  })
}

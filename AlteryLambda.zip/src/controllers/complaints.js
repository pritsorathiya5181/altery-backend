const AWS = require('aws-sdk')

AWS.config.update({
  region: 'us-east-1',
  accessKeyId:'AKIAV3YS7YLB25VGNF6R',
  secretAccessKey: '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',
})

const client = new AWS.DynamoDB.DocumentClient()
const tableName = 'complaints'

var params = {
  TableName: tableName,
}

exports.getAllComplaints =async  () => {
  var params = {
    TableName: tableName,
  }
  const complaintsResponsse = await scanDynamoRecords(params, []);
  
  return complaintsResponsse;
}

async function scanDynamoRecords(scanParams, itemArray) {
  try {
    const dynamoData = await client.scan(scanParams).promise();
    itemArray = itemArray.concat(dynamoData.Items);
    if (dynamoData.LastEvaluatedKey) {
      scanParams.ExclusiveStartkey = dynamoData.LastEvaluatedKey;
      return await scanDynamoRecords(scanParams, itemArray);
    }
    
    if (itemArray.length > 0) {
        return {
          message: 'Successfully fetched all complaints',
          success: true,
          complaints: itemArray,
        }
      } else {
        return {
          message: 'No complaints found',
          success: false,
        }
      }
  } catch(error) {
    return {
        message: 'Unable to get all complaints',
        success: false,
      }
  }
}


exports.getComplaint = async (complaintBody) => {
  var complaintId = complaintBody.complaintId
  var params = {
    TableName: tableName,
    Key: {
      complaintId: complaintId,
    },
  }

   return await client.get(params).promise().then((response) => {
    return {
      message: 'Successfully fetched complaint',
          success: true,
          complaint: response.Item,
    };
  }, (error) => {
    console.error('Do your custom error handling here. I am just gonna log it: ', error);
  });
}

exports.updateComplaintStatus = async (updateComplaintBody) => {
  var complaintId = updateComplaintBody.complaintId
  var params = {
    TableName: tableName,
    Key: {
      complaintId: complaintId,
    },
    UpdateExpression: 'set complaintStatus = :complaintStatus',
    ExpressionAttributeValues: {
      ':complaintStatus': updateComplaintBody.complaintStatus,
    },
    ReturnValues: 'UPDATED_NEW',
  }
  
  const sns = new AWS.SNS({
    region: 'us-east-1'
  })

  const snsParams = {
    Subject: 'Complaint status changed',
    Message: `Hello, \n Hope you are doing fine! \n Your complaint status has been changed to ${updateComplaintBody.complaintStatus}!!`,
    TopicArn: 'arn:aws:sns:us-east-1:403229885123:AlterySnsTopic',
    MessageStructure: 'string',
    MessageAttributes: {
            'email': {
                DataType: 'String',
                StringValue: updateComplaintBody.useremail
            }
        }
  }
    
  return await client.update(params).promise().then(async (response) => {
     const successResponse = {
        message: 'Successfully updated complaint',
        success: true,
      }
        
        const snsData = await sns.publish(snsParams).promise();

      return successResponse;
  }, (error) => {
    const errorResponse = {
        message: 'Unable to update complaint',
        success: true,
      }
      return errorResponses
  })
}

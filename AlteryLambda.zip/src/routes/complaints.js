const router = require('express').Router()
const complaintsController = require('../controllers/complaints')
const s3ImageController = require('../controllers/s3ImageController')

//GET ALL COMPLAINTS
router.get('/find', complaintsController.getAllComplaints)

//ADD NEW COMPLAINTS
router.post(
  '/addComplaints',
  s3ImageController.saveImage,
  complaintsController.addNewComplaints
)

//GET A COMPLAINT
router.get('/:complaintId', complaintsController.getComplaint)

//UPDATE A COMPLAINT
router.put('/:complaintId', complaintsController.updateComplaintStatus)

module.exports = router

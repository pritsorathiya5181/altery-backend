const complaintcontroller = require('./src/controllers/complaints')
const s3Contoller = require('./src/controllers/s3ImageController')

exports.handler = async (event) => {
  console.log('Request Event: ', event)
  let response
  switch (true) {
    case event['context']['http-method'] === 'GET' &&
      event['context']['resource-path'] === "/findcomplaints":
      response = await complaintcontroller.getAllComplaints()
      break
    case event['context']['http-method'] === 'POST' &&
      event['context']['resource-path'] === "/findcomplaint":
      const complaintBody = event['body-json']
      response = await complaintcontroller.getComplaint(complaintBody)
      break
    case event['context']['http-method'] === 'POST' &&
      event['context']['resource-path'] === "/addcomplaints":
      const newComplaintBody = event['body-json']
      response = await s3Contoller.addNewComplaints(newComplaintBody)
      break
    case event['context']['http-method'] === 'POST' &&
      event['context']['resource-path'] === "/updatecomplaints":
      const updateComplaintBody = event['body-json']
      response = await complaintcontroller.updateComplaintStatus(updateComplaintBody)
      break
    default:
      response = buildResponse(404, '404 Not Found')
  }
  return response
}

function buildResponse(statusCode, body) {
  return {
    statusCode: statusCode,
    // headers: {
    //     'Access-Control-Allow-Origin': '*',
    //     'Content-Type': 'application/json'
    // },
    body: JSON.stringify(body),
  }
}
